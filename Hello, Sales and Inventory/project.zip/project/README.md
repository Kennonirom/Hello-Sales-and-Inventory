# Hello, Sales & Inventory
#### Video Demo:  <URL HERE>
#### Description: A Basic Sales and Inventory that calculates Yearly Sales, tracks your Inventory and Processes Items
